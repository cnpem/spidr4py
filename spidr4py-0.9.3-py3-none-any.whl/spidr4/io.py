# Copyright (c) 2019 and onward National Institute for Subatomic Physics Nikhef
# SPDX-License-Identifier: MIT

import struct
from spidr4 import bitfield

_SPIDR4_HEADER="SPIDR4\0\0".encode('ascii')
_WORD_FORMAT="<Q"

GROUP_PIXEL_DATA = 0x0
GROUP_CONFIG_SETTINGS = 0x1
GROUP_ENV_SENSOR_DATA = 0x2
GROUP_USER_DATA = 0x7

ENCODING_BINARY = 0x0
ENCODING_JSON = 0x1
ENCODING_USER = 0x3

GROUP_TPX4DATA_TOP = 0x0000
GROUP_TPX4DATA_BOT = 0x0001
GROUP_TPX4DATA = 0x0002
GROUP_TPX4PIXCFG = 0x1000
GROUP_CHIPINFO = 0x1401
GROUP_BOARDINFO = 0x1402
GROUP_RUNINFO = 0x1403
GROUP_TPX4CFG = 0x1404
GROUP_CTRLCFG = 0x1405
GROUP_CTRLSENSE = 0x2400


class Spidr4Header(bitfield.BitField):
    frameType = bitfield.Field(16, 48)
    groupId = bitfield.Field(4, 60)
    contentEncoding = bitfield.Field(2, 58)
    contentId = bitfield.Field(10, 48)
    streamId = bitfield.Field(16, 32)
    contentSize = bitfield.Field(32, 0)


class Spidr4FileStream:
    def __init__(self, stream):
        self._stream = stream
        self._cursor = 1
        self._next_header = 1
        self.group = -1
        hdr = stream.read(8)

        if hdr != _SPIDR4_HEADER:
            raise IOError("Spidr4 data-file not recognized")

    def _next_word(self):
        self._cursor += 1
        buf = self._stream.read(8)
        if buf is None or len(buf) != 8:
            raise StopIteration()
        return struct.unpack(_WORD_FORMAT, buf)[0]

    def __iter__(self):
        return self

    def dataJSON(self):
        if self._cursor != self._next_header - self.header.contentSize:
            raise IOError("File cursor at wrong location")
        # TODO
        raise NotImplementedError()

    def data64b(self):
        def _generator():
            while self._cursor != self._next_header:
                yield self._next_word()

        return _generator()


    def __next__(self):
        # Seek until the we're at the next header
        while self._cursor != self._next_header:
            self._next_word()
        self.header = Spidr4Header(self._next_word())
        self.group = self.header.groupId

        self._next_header += self.header.contentSize + 1
        return self


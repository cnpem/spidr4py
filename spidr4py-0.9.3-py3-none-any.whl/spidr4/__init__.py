# Copyright (c) 2019 and onward National Institute for Subatomic Physics Nikhef
# SPDX-License-Identifier: MIT

try:
    import spidr4._version
    __version__ = _version.version
except ImportError:
    __version__ = "0.0.0-dev"



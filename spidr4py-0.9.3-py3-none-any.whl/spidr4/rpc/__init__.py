# Copyright (c) 2019 and onward National Institute for Subatomic Physics Nikhef
# SPDX-License-Identifier: MIT

try:
    import os
    import sys
    from .common_pb2 import *
    from .common_pb2_grpc import *
    from .control_pb2 import *
    from .control_pb2_grpc import *
    from .peripheral_pb2_grpc import *
    from .peripheral_pb2 import *
    from .pixelchip_pb2 import *
    from .pixelchip_pb2_grpc import *
    from .daq_pb2 import *
    from .daq_pb2_grpc import *

except ImportError:
    raise RuntimeError("Generated gRPC/protobuf code not found")

EMPTY = Empty()

# Copyright (c) 2019 and onward National Institute for Subatomic Physics Nikhef
# SPDX-License-Identifier: MIT

import zeroconf
from zeroconf import ServiceBrowser, Zeroconf, ServiceListener, IPVersion, RecordUpdateListener, DNSQuestionType
import time
import grpc
from spidr4 import rpc
import os
from typing import Awaitable, Dict, List, Optional, Tuple, Type, Union, cast

os.environ['GRPC_DNS_RESOLVER'] = 'native'

TIMEOUT = 5

# actual service name
REAL_SERVICE = "_spidr4._tcp.local."
META_SERVICE = "_ssh._tcp.local."
SPIDR4_PREFIX = "spidr4-"
SPIDR4_SERVICE = [REAL_SERVICE, META_SERVICE]
SPIDR4PORT = 50051


class HostAndAddress:

    def __init__(self,
                 hostname: str or None = None,
                 addresses: list or str or None = None,
                 info: zeroconf.ServiceInfo or None = None,
                 port: int = SPIDR4PORT):

        if info:
            ipv6 = info.parsed_scoped_addresses(version=zeroconf.IPVersion.V6Only)
            ipv4 = info.parsed_addresses(version=zeroconf.IPVersion.V4Only)

            def bracketize(x :str):
                return f"[{x}]"

            if len(ipv6) > 0:
                # We'll have to perform some magic to make IPv6 work
                ipv6 = [bracketize(x) for x in ipv6]

            self.addresses = ipv6 + ipv4
            self.hostname = info.server
        else:
            self.hostname = hostname
            if addresses is None:
                addresses = []
            elif isinstance(addresses, str):
                addresses = [addresses]
            self.addresses = addresses
        
        self._port = port
        self._ch = None

    def set_port(self, port: int):
        self._port = port

    @staticmethod
    def _try_connect(host, port) -> Optional[grpc.Channel]:
        try:
            ch = grpc.insecure_channel(f"{host}:{port}")
            control = rpc.ControlInfoStub(ch)
            control.GetVersion(rpc.EMPTY)
            return ch
        except grpc.RpcError:
            return None

    def connect(self) -> grpc.Channel:
        hosts = list(self.addresses)
        if self.hostname:
            hosts.append(self.hostname)

        for host in hosts:
            channel = self._try_connect(host, self._port)
            if channel:
                channel.host = host
                return channel
        raise RuntimeError(f"Failed to connect {str(self)}")

    def __str__(self):
        return f"hostname={self.hostname}, addresses={self.addresses}"


class FindSpidr4(ServiceListener, RecordUpdateListener):

    def __init__(self):
        self._spidrs = []

    def get_spidrs(self) -> List[HostAndAddress]:
        return self._spidrs

    def add_service(self, zeroconf : Zeroconf, type, name) -> None:
        info = zeroconf.get_service_info(type, name)
        # This should be it
        is_real_service = type == REAL_SERVICE

        # This is for backwards compatibility
        is_meta_service = name.startswith(SPIDR4_PREFIX) and type == META_SERVICE

        if not is_real_service and not is_meta_service:
            return

        self._spidrs.append(HostAndAddress(info=info))

    def async_update_records(self, zc, now, records):
        pass

    def remove_service(self, zeroconf, type, name):
        pass

    def update_service(self, zeroconf, type, name):
        pass


def find_spidrs4s() -> List[HostAndAddress]:
    # Simple time-out mechanism
    pfound = -TIMEOUT
    zeroconf = Zeroconf(ip_version=IPVersion.All)

    listener = FindSpidr4()
    browser = ServiceBrowser(zeroconf, SPIDR4_SERVICE, listener)
    try:
        while pfound < len(listener.get_spidrs()):
            time.sleep(0.1)
            pfound += 2
    finally:
        zeroconf.close()
    return listener.get_spidrs()


def find_and_connect(hostname: str or int, port: int or None = None) -> grpc.Channel:
    """
    Find a spidr4 host and connect to it, trying several methods.

    :param hostname:
    :return:
    """
    if isinstance(hostname, int) or hostname.isdigit():
        spidrs = sorted(find_spidrs4s(), key=lambda x: x.hostname)
        idx = int(hostname)
        if idx < 0 or idx >= len(spidrs):
            raise RuntimeError(f"Can't find spidr with index {idx}")
        else:
            haa = spidrs[idx]
    else:
        haa = HostAndAddress(hostname)

    if port:
        haa.set_port(port)

    try:
        return haa.connect()
    except RuntimeError:
        pass
    address = hostname
    with Zeroconf(ip_version=IPVersion.All) as zc:
        if address.endswith(".local"):
            address += "."
        elif not address.endswith(".local."):
            address += ".local."
        si = zc.get_service_info(type_=META_SERVICE, name=address)
        if si:
            return HostAndAddress(info=si).connect()
        else:
            raise RuntimeError(f"Failed to connect {hostname}")


if __name__ == "__main__":

    # spidrs = find_spidrs4s()
    # for spidr in spidrs:
    #     print(spidr.addresses)

    conn = find_and_connect("spidr4-2874d097")
    print(conn)
